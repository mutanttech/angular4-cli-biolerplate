#!/usr/bin/env node
console.dir(require('optimist').argv);
