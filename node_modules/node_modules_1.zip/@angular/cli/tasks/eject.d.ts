export declare const pluginArgs: symbol;
export declare const postcssArgs: symbol;
declare var _default: any;
export default _default;
